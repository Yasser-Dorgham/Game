package harrypotter.model.character;

import java.io.IOException;

public interface Champion {
	
	public void useTrait() throws IOException;

}
