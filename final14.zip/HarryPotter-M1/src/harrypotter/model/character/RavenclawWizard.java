package harrypotter.model.character;

public class RavenclawWizard extends Wizard implements Champion {

	public RavenclawWizard(String name) {
		
		super(name, 750, 700);

	}

	public void useTrait() {

		if (this.getTraitCooldown()==0)
			if (this.getListener()!= null)
			this.getListener().onRavenclawTrait();

	}

}
