package harrypotter.model.tournament;

import harrypotter.model.character.Champion;
import harrypotter.model.character.GryffindorWizard;
import harrypotter.model.character.HufflepuffWizard;
import harrypotter.model.character.SlytherinWizard;
import harrypotter.model.character.Wizard;
import harrypotter.model.character.WizardListener;
import harrypotter.model.magic.DamagingSpell;
import harrypotter.model.magic.HealingSpell;
import harrypotter.model.magic.Potion;
import harrypotter.model.magic.RelocatingSpell;
import harrypotter.model.magic.Spell;
import harrypotter.model.world.Cell;
import harrypotter.model.world.ChampionCell;
import harrypotter.model.world.CollectibleCell;
import harrypotter.model.world.CupCell;
import harrypotter.model.world.Direction;
import harrypotter.model.world.EmptyCell;
import harrypotter.model.world.ObstacleCell;
import harrypotter.model.world.TreasureCell;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public abstract class Task implements WizardListener {

	private ArrayList<Champion> champions;
	private Cell[][] map;
	private Champion currentChamp;
	private int allowedMoves;
	private boolean traitActivated;
	private ArrayList<Potion> potions;
	private TaskListener listener;

	public Task(ArrayList<Champion> champions) throws IOException {

		this.champions = champions;
		map = new Cell[10][10];
		potions = new ArrayList<Potion>();
		loadPotions("Potions.csv");
		allowedMoves = 1;
		for(int i = 0;  i < this.champions.size(); i++)
			if (champions.get(i) instanceof Wizard)
			{
			{
			Wizard x = (Wizard) champions.get(i);  
			x.setHp(x.getDefaultHp());
			x.setIp(x.getDefaultIp());
			x.setTraitCooldown(x.getTraitCooldown());
			allowedMoves = 1;
			for(int j = 0; j < x.getSpells().size(); j++)
				{
					x.getSpells().get(j).setCoolDown(0);
				}
			traitActivated = false;
			}
			}
		

	}

	public abstract void generateMap() throws IOException;

	public ArrayList<Champion> getChampions() {

		return champions;

	}

	public Cell[][] getMap() {

		return map;

	}

	public Champion getCurrentChamp() {

		return currentChamp;

	}

	public ArrayList<Potion> getPotions() {

		return potions;

	}

	public int getAllowedMoves() {

		return allowedMoves;

	}

	public boolean isTraitActivated() {

		return traitActivated;

	}

	public void setCurrentChamp(Champion currentChamp) {

		this.currentChamp = currentChamp;

	}

	public void setAllowedMoves(int allowedMoves) {

		this.allowedMoves = allowedMoves;

	}

	public void setTraitActivated(boolean traitActivated) {

		this.traitActivated = traitActivated;

	}
	public TaskListener getListener() {
		return listener;
	}
	public void setListener(TaskListener listener) {
		this.listener = listener;
	}

	private void loadPotions(String filePath) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();

		while (line != null) {

			String[] content = line.split(",");
			potions.add(new Potion(content[0], Integer.parseInt(content[1])));
			line = br.readLine();

		}

		br.close();

	}

	public void initializeAllEmpty() {

		for (int i = 0; i < map.length; i++) {

			for (int j = 0; j < map[i].length; j++) {

				map[i][j] = new EmptyCell();

			}

		}

	}

	public void allocateChampions() {

		for (int i = 0; i < champions.size(); i++) {

			Champion champ = champions.get(i);

			if (i == 0) {

				map[9][0] = new ChampionCell(champ);
				((Wizard) champ).setLocation(new Point(9, 0));

			}

			else if (i == 1) {

				map[9][9] = new ChampionCell(champ);
				((Wizard) champ).setLocation(new Point(9, 9));

			} else if (i == 2) {

				map[0][9] = new ChampionCell(champ);
				((Wizard) champ).setLocation(new Point(0, 9));

			} else {

				map[0][0] = new ChampionCell(champ);
				((Wizard) champ).setLocation(new Point(0, 0));

			}

		}

	}

	public void allocatePotions() {

		int i = 0;
		while (i < 10) {

			int randomX = (int) (Math.random() * 10);
			int randomY = (int) (Math.random() * 10);

			if (map[randomX][randomY] instanceof EmptyCell) {

				int r = (int) (Math.random() * potions.size());
				map[randomX][randomY] = new CollectibleCell(potions.get(r));
				i++;

			}

		}

	}
	public void moveForward() throws IOException
	{
		//System.out.println("da5al el move" + ((Wizard)currentChamp).getName());
		if (this.getCurrentChamp() instanceof Wizard && this.getCurrentChamp()!= null)
		{
			Wizard z = (Wizard) this.getCurrentChamp();
			Point c = ((Wizard)currentChamp).getLocation();
			Point d= getTargetPoint(Direction.FORWARD);
			
			Cell x = getMap()[d.x][d.y];
			if(d.x>=0 && d.x <= 9 && d.y>=0 && d.y<=9)
			{
				//System.out.println("da5al el move2 " + ((Wizard)currentChamp).getName());
			if(x instanceof EmptyCell && (!(this instanceof FirstTask && d.x ==4 && d.y ==4)))
				{
				getMap()[d.x][d.y] = new ChampionCell(this.getCurrentChamp());
					
				}
			if(x instanceof CollectibleCell)
				{
				
					z.getInventory().add(((CollectibleCell) x).getCollectible());
					getMap()[d.x][d.y] = new ChampionCell(this.getCurrentChamp());
				}	
			if (this instanceof FirstTask && d.x ==4 && d.y ==4) //kona nasyen di fel 4 moves
			{ 
				//System.out.println("da5al el egg cell");
				((FirstTask)this).fire();
				
				this.getChampions().remove(z);
				((FirstTask)this).getWinners().add(z);
				//System.out.println(((FirstTask)this).getWinners().size() + "el winners'");
				

				//currentChamp = null;
			}
			if(this instanceof SecondTask && x instanceof TreasureCell && ((Wizard)((TreasureCell)x).getOwner()).getName().equals(((Wizard)currentChamp).getName()))
			{
				((SecondTask)this).getWinners().add(z);
				
				((SecondTask)this).getChampions().remove(z);
				//currentChamp = null;
				getMap()[c.x][c.y]=new EmptyCell();
				getMap()[d.x][d.y]=new EmptyCell();
				if(!champions.isEmpty())
				{
				currentChamp = champions.get(0);
				setTraitActivated(false);
				setAllowedMoves(1);
				Wizard n = ((Wizard)currentChamp);
				if (n!= null)
				{
				if(n.getTraitCooldown()>0)
				((Wizard)currentChamp).setTraitCooldown(((Wizard)currentChamp).getTraitCooldown()-1);// lazem ne decrement mesh ne increment we lazem fe endturn mesh finalize
				
				for(int i = 0; i<n.getSpells().size() ; i++)
				{
					if(n.getSpells().get(i).getCoolDown()>0)
						n.getSpells().get(i).setCoolDown(n.getSpells().get(i).getCoolDown()-1);
				}
				return;
				}
				}
			else
				((SecondTask)this).notifyOnFinishingSecondTask();
			
			}
			if(this instanceof ThirdTask && x instanceof CupCell)		
				{//System.out.println(c.x+" "+c.y);
				((ThirdTask)this).notifyOnFinishingThirdTask();
				}
			z.setLocation(getTargetPoint(Direction.FORWARD));
			getMap()[c.x][(c.y)] = new EmptyCell();
		}
		
		}
		finalizeAction();
	}
		
	
	public void moveBackward() throws IOException
	{
		if (this.getCurrentChamp() instanceof Wizard && this.getCurrentChamp()!= null)
		{
			Wizard z = (Wizard) this.getCurrentChamp();
			Point c = ((Wizard)currentChamp).getLocation();
			Point d= getTargetPoint(Direction.BACKWARD);
			Cell x = getMap()[getTargetPoint(Direction.BACKWARD).x][getTargetPoint(Direction.BACKWARD).y];
			
			if(d.x>=0 && d.x <= 9 && d.y>=0 && d.y<=9)
			{
				if(x instanceof EmptyCell && (!(this instanceof FirstTask && d.x ==4 && d.y ==4)))
				{
					getMap()[d.x][d.y] = new ChampionCell(this.getCurrentChamp());
				}
			if(x instanceof CollectibleCell)
				{
				//System.out.println("da5al2");
					z.getInventory().add(((CollectibleCell) x).getCollectible());
					getMap()[d.x][d.y] = new ChampionCell(this.getCurrentChamp());
				}	
			if (this instanceof FirstTask && d.x ==4 && d.y ==4)
			{
				((FirstTask)this).fire();
				((FirstTask)this).getWinners().add(z);
				this.getChampions().remove(z);
				System.out.println(((FirstTask)this).getWinners().size() + "el winners'");
				
				
			}
			if(this instanceof SecondTask && x instanceof TreasureCell && ((Wizard)((TreasureCell)x).getOwner()).getName().equals(((Wizard)currentChamp).getName()))
			{
				((SecondTask)this).getWinners().add(z);
				
				((SecondTask)this).getChampions().remove(z);
				//currentChamp = null;
				getMap()[c.x][c.y]=new EmptyCell();
				getMap()[d.x][d.y]=new EmptyCell();
				if (!champions.isEmpty())
				{
				currentChamp = champions.get(0);
				setTraitActivated(false);
				setAllowedMoves(1);
				Wizard n = ((Wizard)currentChamp);
				if (n!= null)
				{
				if(n.getTraitCooldown()>0)
				((Wizard)currentChamp).setTraitCooldown(((Wizard)currentChamp).getTraitCooldown()-1);// lazem ne decrement mesh ne increment we lazem fe endturn mesh finalize
				
				for(int i = 0; i<n.getSpells().size() ; i++)
				{
					if(n.getSpells().get(i).getCoolDown()>0)
						n.getSpells().get(i).setCoolDown(n.getSpells().get(i).getCoolDown()-1);
				}
				
				return;	
				}
				}
				else
					((SecondTask)this).notifyOnFinishingSecondTask();
			}
			if(this instanceof ThirdTask && x instanceof CupCell)		
				{
				((ThirdTask)this).notifyOnFinishingThirdTask();
				}
			z.setLocation(getTargetPoint(Direction.BACKWARD));
			getMap()[c.x][(c.y)] = new EmptyCell();
		
		}
		finalizeAction();
		}
	}
	public void moveLeft() throws IOException
	{
		if (this.getCurrentChamp() instanceof Wizard && this.getCurrentChamp()!= null)
		{
			
			Wizard z = (Wizard) this.getCurrentChamp();
			Point c = ((Wizard)currentChamp).getLocation();
			Point d= getTargetPoint(Direction.LEFT);
			Cell x = getMap()[getTargetPoint(Direction.LEFT).x][getTargetPoint(Direction.LEFT).y];
			if(d.x>=0 && d.x <= 9 && d.y>=0 && d.y<=9)
			{
			if(x instanceof EmptyCell && (!(this instanceof FirstTask && d.x ==4 && d.y ==4)))
				{
				getMap()[d.x][d.y] = new ChampionCell(this.getCurrentChamp());
					
				}
			if(x instanceof CollectibleCell)
				{
					z.getInventory().add(((CollectibleCell) x).getCollectible());
					getMap()[d.x][d.y] = new ChampionCell(this.getCurrentChamp());
					//System.out.println("da5al2");
				}	
			if (this instanceof FirstTask && d.x ==4 && d.y ==4)
			{
				((FirstTask)this).fire();
				((FirstTask)this).getWinners().add(z);
				//currentChamp = null;
				//System.out.println(((FirstTask)this).getWinners().size() + "el winners'");
				this.getChampions().remove(z);
			
			
			}
			if(this instanceof SecondTask && x instanceof TreasureCell && ((Wizard)((TreasureCell)x).getOwner()).getName().equals(((Wizard)currentChamp).getName()))
			{
				((SecondTask)this).getWinners().add(z);
				//currentChamp = null;
				((SecondTask)this).getChampions().remove(z);
				getMap()[c.x][c.y]=new EmptyCell();
				getMap()[d.x][d.y]=new EmptyCell();
				if (!champions.isEmpty())
				{
				currentChamp = champions.get(0);
				setTraitActivated(false);
				setAllowedMoves(1);
				Wizard n = ((Wizard)currentChamp);
				if (n!= null)
				{
				if(n.getTraitCooldown()>0)
				((Wizard)currentChamp).setTraitCooldown(((Wizard)currentChamp).getTraitCooldown()-1);// lazem ne decrement mesh ne increment we lazem fe endturn mesh finalize
				
				for(int i = 0; i<n.getSpells().size() ; i++)
				{
					if(n.getSpells().get(i).getCoolDown()>0)
						n.getSpells().get(i).setCoolDown(n.getSpells().get(i).getCoolDown()-1);
				}
				return;
				}
				}
				else
					((SecondTask)this).notifyOnFinishingSecondTask();
			}
			if(this instanceof ThirdTask && x instanceof CupCell)		
				{
				((ThirdTask)this).notifyOnFinishingThirdTask();
				}
			z.setLocation(getTargetPoint(Direction.LEFT));
			getMap()[c.x][(c.y)] = new EmptyCell();
			
		}
		
		finalizeAction();
		}
		
	}
	public void moveRight() throws IOException
	{
		if (this.getCurrentChamp() instanceof Wizard && this.getCurrentChamp()!= null)
		{
			Wizard z = (Wizard) this.getCurrentChamp();
			Point c = ((Wizard)currentChamp).getLocation();
			Point d= getTargetPoint(Direction.RIGHT);
			Cell x = getMap()[getTargetPoint(Direction.RIGHT).x][getTargetPoint(Direction.RIGHT).y]; 
			if(d.x>=0 && d.x <= 9 && d.y>=0 && d.y<=9)
			{
			if(x instanceof EmptyCell && (!(this instanceof FirstTask && d.x ==4 && d.y ==4)))
				{
				getMap()[d.x][d.y] = new ChampionCell(this.getCurrentChamp());
				}
			if(x instanceof CollectibleCell)
				{
				//System.out.println("da5al2");
					z.getInventory().add(((CollectibleCell) x).getCollectible());
					getMap()[d.x][d.y] = new ChampionCell(this.getCurrentChamp());
				}	
			if (this instanceof FirstTask && d.x ==4 && d.y ==4)
			{
				((FirstTask)this).fire();
				((FirstTask)this).getWinners().add(z);
				//System.out.println(((FirstTask)this).getWinners().size() + "el winners'");
				//currentChamp = null;
				this.getChampions().remove(z);
				
				
			}
			if(this instanceof SecondTask && x instanceof TreasureCell && ((Wizard)((TreasureCell)x).getOwner()).getName().equals(((Wizard)currentChamp).getName()))
			{
				((SecondTask)this).getWinners().add(z);
				
				((SecondTask)this).getChampions().remove(z);
				//currentChamp = null;
				getMap()[c.x][c.y]=new EmptyCell();
				getMap()[d.x][d.y]=new EmptyCell();
				if (! champions.isEmpty())
				{
				currentChamp = champions.get(0);
				setTraitActivated(false);
				setAllowedMoves(1);
				Wizard n = ((Wizard)currentChamp);
				if (n!= null)
				{
				if(n.getTraitCooldown()>0)
				((Wizard)currentChamp).setTraitCooldown(((Wizard)currentChamp).getTraitCooldown()-1);// lazem ne decrement mesh ne increment we lazem fe endturn mesh finalize
				
				for(int i = 0; i<n.getSpells().size() ; i++)
				{
					if(n.getSpells().get(i).getCoolDown()>0)
						n.getSpells().get(i).setCoolDown(n.getSpells().get(i).getCoolDown()-1);
				}
				return;
				}
				}
				else
					((SecondTask)this).notifyOnFinishingSecondTask();
			}
			if(this instanceof ThirdTask && x instanceof CupCell)		
				{
				((ThirdTask)this).notifyOnFinishingThirdTask();
				}
				z.setLocation(getTargetPoint(Direction.RIGHT));
				getMap()[c.x][(c.y)] = new EmptyCell();
		}
		}
		finalizeAction();
	}
	/*public Point getTargetPoint(Direction d)
	{
		int r=0;
		int c = 0;
		if(currentChamp!=null){
				Wizard z = (Wizard) currentChamp;
				Point p = z.getLocation();
				
				switch(d)
					{
						case FORWARD : r = p.x-1; c=p.y;break;
						case BACKWARD : r= p.x+1; c=p.y; break;
						case RIGHT : r= p.x; c= (p.y)+1; break;
						default  : r= p.x; c=(p.y)-1; break;
						
					}}
			
		Point l = new Point(r,c);
		return l;
	}*/
	public Point getTargetPoint(Direction d)
	{
		
		Wizard z = (Wizard) currentChamp;
		Point p;
		if (z!=null)
		 p =z.getLocation();
		else
			p=new Point(5,5);
		 
		int  r = p.x ;
		int  c = p.y;
		
			 
			
		
		if (d.equals(Direction. FORWARD))
			r--;
		if (d.equals(Direction.BACKWARD))
				r++;
		if (d.equals(Direction.RIGHT))
				c++;
		if (d.equals(Direction.LEFT))
				c--;
		
		return (new Point (r,c));
	}
	public void useSpell(Spell s) throws IOException
	{
		if(this.getCurrentChamp() instanceof Wizard )
			{
				Wizard z = (Wizard) this.getCurrentChamp();
				int x = z.getIp();
				x -= s.getCost();
				if (x<0)
					z.setIp(0);
				else
					z.setIp(x);
				s.setCoolDown(s.getDefaultCooldown());
			}
		finalizeAction();
				
	}
	public void castDamagingSpell(DamagingSpell s,Direction d) throws IOException
	{
		if(s.getCoolDown()==0)
		{
		Point p = getTargetPoint(d);
		if (p.x>=0 && p.y>=0 && p.x<=9 && p.y<=9)
		{
		Cell c = getMap()[p.x][p.y];
		if(c instanceof ChampionCell)
		{
	
				Wizard z = (Wizard) ((ChampionCell)c).getChamp();
				int h= z.getHp();
				if(z instanceof HufflepuffWizard && this instanceof ThirdTask)
					{
						h=h-(s.getDamageAmount()/2);
					}
				else
					h=h-s.getDamageAmount();
				if (h<=0)
				{
					z.setHp(0);
					getChampions().remove(z);
					getMap()[p.x][p.y] = new EmptyCell();
					
				}
				else
					z.setHp(h);
				
				
		}
		
		if (c instanceof ObstacleCell)
		{
			int hp = ((ObstacleCell)c).getObstacle().getHp();
			hp = hp - (s.getDamageAmount());
			if (hp<=0)
				getMap()[p.x][p.y] = new EmptyCell();
			else
			((ObstacleCell)c).getObstacle().setHp(hp);
		}
		useSpell(s);	
	//el mafrood lw el HP wasal zero atala3o men el tournament
	}
	}
	}
	public void castRelocatingSpell(RelocatingSpell s , Direction d, Direction t , int r) throws IOException
	{
		if(s.getCoolDown()==0)
		{
		Point po = getTargetPoint(d);
		if (po.x>=0 && po.x<=9 && po.y>=0 && po.y<=9)
		{
		Cell i = getMap()[po.x][po.y];
		Point pc = ((Wizard)currentChamp).getLocation();
		int x = pc.x;
		int y = pc.y;
		switch (t){
		case FORWARD : x-=r; break;
		case BACKWARD : x+=r; break;
		case RIGHT : y+=r; break;
		case LEFT : y-=r; break;
		default : x=x; y=y;
		}
		if(x<=9 && y<=9 && x>=0 && y>=0)
		{
		Cell f = getMap()[x][y];
		if (f instanceof EmptyCell)
		{
		if (i instanceof ChampionCell )
		{
			getMap()[x][y]= new ChampionCell(((ChampionCell)i).getChamp());
		}
		if (i instanceof ObstacleCell)
		{
			getMap()[x][y] = new ObstacleCell(((ObstacleCell)i).getObstacle());
		}
		
		}
		if (f instanceof ObstacleCell)
		{
			if (i instanceof ObstacleCell)
			{
				getMap()[x][y] = new ObstacleCell(((ObstacleCell)i).getObstacle());
			}
			
		}
		
		}
		
		getMap()[po.x][po.y] = new EmptyCell();
		}
		
		
		useSpell(s);
		}
	}
	public void castHealingSpell(HealingSpell s) throws IOException
	{
		if (currentChamp instanceof Wizard)
		{
			if(s.getCoolDown()==0)
			{
			Wizard z = (Wizard) currentChamp;
			int x = z.getHp();
			x = x + s.getHealingAmount();
			if (x > z.getDefaultHp())
				z.setHp(z.getDefaultHp());
			else
				z.setHp(x); // wade7 en 3ady en el hp yeb2a aktar men el default ... di sala7et 3 errors we 5alethom failures 
		}
		}
		useSpell(s);
	}
		
	public void endTurn() throws IOException
	{
		//System.out.println(champions.size());
		if (champions.size()==0){
			if (this instanceof FirstTask)
			{
				//System.out.println("da5al end we first");
				((FirstTask)this).notifyOnFinishingFirstTask();
				/*if(getListener()!= null)
				{
					System.out.println("da5al el condition");
				getListener().onFinishingFirstTask(((FirstTask)this).getWinners());
			}*/
			}
			if (this instanceof SecondTask)
				((SecondTask)this).notifyOnFinishingSecondTask();
			//if (this instanceof ThirdTask)
				//((ThirdTask)this).notifyOnFinishingThirdTask();
		}
		else
		{
		if (champions.contains(currentChamp))
				{
				champions.add(currentChamp);
				champions.remove(0);
				}
		
		
		currentChamp = champions.get(0);
		setTraitActivated(false);
		setAllowedMoves(1);
		Wizard z = ((Wizard)currentChamp);
		if (z!= null)
		{
		if(z.getTraitCooldown()>0)
		((Wizard)currentChamp).setTraitCooldown(((Wizard)currentChamp).getTraitCooldown()-1);// lazem ne decrement mesh ne increment we lazem fe endturn mesh finalize
		
		for(int i = 0; i<z.getSpells().size() ; i++)
		{
			if(z.getSpells().get(i).getCoolDown()>0)
				z.getSpells().get(i).setCoolDown(z.getSpells().get(i).getCoolDown()-1);
		}
		}
		
		}
	}
	public void usePotion(Potion p)
	{
		if (currentChamp instanceof Wizard)
		{
			Wizard z = (Wizard) currentChamp;
			int x = z.getIp() + p.getAmount();
			//if (x > z.getDefaultIp())
				/*z.setIp(z.getDefaultIp());
			else*/
				z.setIp(x); // wade7 en momken yezeed 3an el default ip
			z.getInventory().remove(p);
			//System.out.println(x);//kona nasyeen di
		}	
	}	
	
	public void onGryffindorTrait()
		{
		if (currentChamp instanceof GryffindorWizard)
		{	
			setTraitActivated(true);
		setAllowedMoves(2);
		
		
		((GryffindorWizard)currentChamp).setTraitCooldown(4);
		}
		}
	public void onSlytherinTrait(Direction d) throws IOException
	{
		//((SlytherinWizard)getCurrentChamp()).setTraitDirection(d);
		Wizard z = (Wizard) getCurrentChamp();
		Point l = ((Wizard)getCurrentChamp()).getLocation(); 
		int x = l.x;
		int y = l.y;
		switch (d){
		case FORWARD : x-=2; break;
		case BACKWARD : x+=2; break;
		case RIGHT : y+=2; break;
		default : y-=2; break;
		
		}
		
		z.setLocation(new Point(x,y));
		getMap() [l.x][l.y]= new EmptyCell();
		getMap()[x][y] = new ChampionCell(currentChamp);
		finalizeAction();
		
	}
	public void onHufflepuffTrait()
	{
		if (currentChamp instanceof HufflepuffWizard)
		{	
		setTraitActivated(true);
		
		}
	}

	
	public void finalizeAction() throws IOException
	{	
		if ( currentChamp!= null && currentChamp instanceof Wizard)
		{
			Wizard z = (Wizard) currentChamp;
			
			allowedMoves--;
			if(allowedMoves == 0)
			{
				if (this instanceof FirstTask)
					((FirstTask)this).endTurn();
				if (this instanceof SecondTask)
					((SecondTask)this).endTurn();
				if(this instanceof ThirdTask)
					((ThirdTask)this).endTurn();
			}
			
			
		}
		
	
	}
	

}
