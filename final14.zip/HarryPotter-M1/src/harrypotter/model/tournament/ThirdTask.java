package harrypotter.model.tournament;

import harrypotter.model.character.Champion;
import harrypotter.model.character.RavenclawWizard;
import harrypotter.model.character.SlytherinWizard;
import harrypotter.model.character.Wizard;
import harrypotter.model.world.Cell;
import harrypotter.model.world.ChampionCell;
import harrypotter.model.world.CupCell;
import harrypotter.model.world.Direction;
import harrypotter.model.world.EmptyCell;
import harrypotter.model.world.PhysicalObstacle;
import harrypotter.model.world.ObstacleCell;
import harrypotter.model.world.WallCell;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ThirdTask extends Task {

	public ThirdTask(ArrayList<Champion> champions) throws IOException {

		super(champions);
		generateMap();
		for (int i = 0; i<champions.size(); i++)
		{
			Wizard z = ((Wizard)champions.get(i));
			z.setListener(this);
		}
		setCurrentChamp(champions.get(0));

	}

	public void generateMap() throws IOException {

		initializeAllEmpty();
		readMap("task3map.csv");
		allocatePotions();

	}

	private void readMap(String filePath) throws IOException {

		Cell[][] map = getMap();
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();

		int i = 0;
		while (line != null) {

			String[] content = line.split(",");

			for (int j = 0; j < content.length; j++) {

				char cellType = content[j].charAt(0);

				switch (cellType) {
				case '0':

					map[i][j] = new EmptyCell();
					break;

				case '5':

					map[i][j] = new WallCell();
					break;

				case '6':

					int hp = (int) ((Math.random() * 101) + 200);
					map[i][j] = new ObstacleCell(new PhysicalObstacle(hp));
					break;

				case '7':

					map[i][j] = new CupCell();
					break;

				case '1':
				case '2':
				case '3':
				case '4':

					int c = Character.getNumericValue(cellType);
					if (c <= getChampions().size()) {

						map[i][j] = new ChampionCell(getChampions().get(c - 1));
						((Wizard)getChampions().get(c-1)).setLocation(new Point (i,j));

					}

					break;

				default:
					
					break;
					
				}

			}

			i++;
			line = br.readLine();

		}

		br.close();

	}
	public void onSlytherinTrait(Direction d) throws IOException
	{
		
		((SlytherinWizard)getCurrentChamp()).setTraitCooldown(10);
		super.onSlytherinTrait(d);
		
	}
	public Object onRavenclawTrait()
	{

		int x = 1;
		int y = 4;
		int l = (((Wizard)getCurrentChamp()).getLocation()).x;
		int m = (((Wizard)getCurrentChamp()).getLocation()).y;
		ArrayList<Direction> r = new ArrayList<Direction>();
		
		if (l<x)
			r.add(Direction.BACKWARD);
		if (l>x)
			r.add(Direction.FORWARD);
		if(y<m)
			r.add(Direction.LEFT);
		if (y>m)
			r.add(Direction.RIGHT);
		
		setTraitActivated(true);
		((RavenclawWizard)getCurrentChamp()).setTraitCooldown(7);
		return r;
	}
	 public void notifyOnFinishingThirdTask() throws IOException
	 {
		 if (getListener() != null)
		 getListener().onFinishingThirdTask(getCurrentChamp()); // badal ma kona 3amlin Tournament.onFinishing.... han-invoke el method 3ala el listener which is of type tournament bardo . bas e7na malnasg access 3ala tournament ela men 5elal el listener
	 }
	
}
