package harrypotter.model.tournament;

import harrypotter.model.character.Champion;
import harrypotter.model.character.GryffindorWizard;
import harrypotter.model.character.HufflepuffWizard;
import harrypotter.model.character.RavenclawWizard;
import harrypotter.model.character.SlytherinWizard;
import harrypotter.model.character.Wizard;
import harrypotter.model.magic.Potion;
import harrypotter.model.world.Cell;
import harrypotter.model.world.ChampionCell;
import harrypotter.model.world.CollectibleCell;
import harrypotter.model.world.Direction;
import harrypotter.model.world.EmptyCell;
import harrypotter.model.world.PhysicalObstacle;
import harrypotter.model.world.ObstacleCell;

import java.awt.Point;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;

public class FirstTask extends Task {
	ArrayList<Point> markedCells;
	ArrayList<Champion> winners;
	
	public FirstTask(ArrayList<Champion> champions) throws IOException {

		super(champions);
		Collections.shuffle(champions);
		generateMap();
		winners=new ArrayList<Champion>();
		if (getChampions().size()!=0)
			setCurrentChamp(getChampions().get(0));
		markedCells = new ArrayList<Point>();
		markCells();
		for (int i = 0; i<champions.size(); i++)
		{
			Wizard z = ((Wizard)champions.get(i));
			z.setListener(this);
		}

	}

	public void generateMap() {

		Cell[][] map = getMap();

		initializeAllEmpty();

		allocateChampions();

		int count = 0;
		while (count < 40) {

			int randomX = (int) (Math.random() * 10);
			int randomY = (int) (Math.random() * 10);

			if (map[randomX][randomY] instanceof EmptyCell
					&& !(randomX == 4 && randomY == 4)) {

				int hp = (int) ((Math.random() * 101) + 200);
				map[randomX][randomY] = new ObstacleCell(new PhysicalObstacle(hp));
				count++;

			}

		}

		allocatePotions();

	}

	public void allocatePotions() {

		Cell[][] map = getMap();

		ArrayList<Potion> potions = getPotions();

		int i = 0;
		while (i < 10) {

			int randomX = (int) (Math.random() * 10);
			int randomY = (int) (Math.random() * 10);

			if (map[randomX][randomY] instanceof EmptyCell
					&& !(randomX == 4 && randomY == 4)) {

				int r = (int) (Math.random() * potions.size());
				map[randomX][randomY] = new CollectibleCell(potions.get(r));
				i++;

			}

		}
	}
	
	public void markCells(){
		if (this.getCurrentChamp() instanceof Wizard){
		ArrayList<Point> list = new ArrayList<Point>(5);	
		Point x = ((Wizard)(this.getCurrentChamp())).getLocation();
		list.add(x);
		Point l = getTargetPoint(Direction.LEFT);
		if (l.x>=0 && l.x<=9 && l.y>=0 && l.y<=9)
			list.add(l);
		Point r = getTargetPoint(Direction.RIGHT);
		if (r.x>=0 && r.x<=9 && r.y>=0 && r.y<=9)
			list.add(r);
		Point u = getTargetPoint(Direction.FORWARD);
		if (u.x>=0 && u.x<=9 && u.y>=0 && u.y<=9)
			list.add(u);
		Point d =  getTargetPoint(Direction.BACKWARD);
		if (d.x>=0 && d.x<=9 && d.y>=0 && d.y<=9)
			list.add(d);
		
		
		 Point a = list.get((int)(Math.random()*list.size()));
		 Point b = list.get((int)(Math.random()*list.size()));
		while(b.x==a.x && b.y==a.y)
		{
			 b = list.get((int)(Math.random()*list.size()));
		}
		markedCells.add(a);
		markedCells.add(b);
		
		}
	}
	
	
	public void fire() throws IOException
	{

		for(int i = 0 ;i< markedCells.size();i++){
		Point a = markedCells.get(i);
		
		if ((this.getMap()[a.x][a.y] instanceof ChampionCell) && a.x<=9 && a.y<=9 && a.x>=0 && a.y>=0)
		{
			Wizard z = ((Wizard) ((ChampionCell)getMap()[a.x][a.y]).getChamp());
			int h = ((Wizard) ((ChampionCell)getMap()[a.x][a.y]).getChamp()).getHp();
			h=h-150;
			if(h<=0)
				{
					((Wizard) ((ChampionCell)getMap()[a.x][a.y]).getChamp()).setHp(0);
					getChampions().remove(((Wizard) ((ChampionCell)getMap()[a.x][a.y]).getChamp()));
					getMap()[a.x][a.y] = new EmptyCell();
					if (! getChampions().isEmpty())
					if ((getChampions().get(getChampions().size()-1)).equals(z))
					{
						if (! getChampions().isEmpty())
						{
						setCurrentChamp (getChampions().get(0));
						setTraitActivated(false);
						setAllowedMoves(1);
						Wizard n = ((Wizard)getCurrentChamp());
						if (n!= null)
						{
						if(n.getTraitCooldown()>0)
						((Wizard)getCurrentChamp()).setTraitCooldown(((Wizard)getCurrentChamp()).getTraitCooldown()-1);// lazem ne decrement mesh ne increment we lazem fe endturn mesh finalize
						
						for(int i1 = 0; i1<n.getSpells().size() ; i1++)
						{
							if(n.getSpells().get(i1).getCoolDown()>0)
								n.getSpells().get(i1).setCoolDown(n.getSpells().get(i1).getCoolDown()-1);
						}
						}
					}
					}
					else
						notifyOnFinishingFirstTask();
					
				}
			else
				((Wizard) ((ChampionCell)getMap()[a.x][a.y]).getChamp()).setHp(h);
			
		}
		}
		 
		
	}
	/*public void finalizeAction() throws IOException
	{
		
		if (getCurrentChamp() instanceof HufflepuffWizard && isTraitActivated())
		{
		}
		else
			{
			fire();
			}	
		int x = ((Wizard)getCurrentChamp()).getLocation().x;
		int y = ((Wizard)getCurrentChamp()).getLocation().y;
		if( x == 4 && y == 4)
			{
				winners.add((Wizard)getCurrentChamp());
				getChampions().remove(getChampions().indexOf((Wizard)getCurrentChamp()));
				
			}
		super.finalizeAction();
	}*/
	public void endTurn() throws IOException
	{
		if (getCurrentChamp() instanceof HufflepuffWizard && isTraitActivated())
		{
		}
		else
			{
			fire();
			}
		markedCells.clear();
		
		super.endTurn();
		markCells();
	}
	public void onSlytherinTrait(Direction d) throws IOException
	{
		((SlytherinWizard)getCurrentChamp()).setTraitCooldown(6);
		super.onSlytherinTrait(d);
		
		
	}
	public void onHufflepuffTrait()
	{
		super.onHufflepuffTrait();
		((HufflepuffWizard)getCurrentChamp()).setTraitCooldown(3);
	}
	public Object onRavenclawTrait()
	{
		setTraitActivated(true);
		((RavenclawWizard)getCurrentChamp()).setTraitCooldown(5);
		return markedCells;
	}
	public void notifyOnFinishingFirstTask() throws IOException
	 {
		if (getListener() != null)//lazem el condition
		{
			//System.out.println("da5al el notify");
		 getListener().onFinishingFirstTask(winners); // badal ma kona 3amlin Tournament.onFinishing.... han-invoke el method 3ala el listener which is of type tournament bardo . bas e7na malnasg access 3ala tournament ela men 5elal el listener
	 }
	 }
	public ArrayList<Point> getMarkedCells() {
		return markedCells;
	}
	 
	public void setMarkedCells(ArrayList<Point> markedCells) {
		this.markedCells = markedCells;
	}
	public ArrayList<Champion> getWinners() {
		return winners;
	}
	public void setWinners(ArrayList<Champion> winners) {
		this.winners = winners;
	}
	
	public static void main(String[] args) throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		ArrayList<Champion> e = new ArrayList<>();
		GryffindorWizard g = new GryffindorWizard("gryff");
		HufflepuffWizard h = new HufflepuffWizard("huff");
		RavenclawWizard r = new RavenclawWizard("raven");
		SlytherinWizard s = new SlytherinWizard("slyth");
		e.add(g);
		e.add(h);
		e.add(r);
		e.add(s);
		FirstTask task = new FirstTask(e);

		for (int i = 0; i < 10; i++)
			for (int j = 0; j < 10; j++)
				task.getMap()[i][j] = new EmptyCell();

		task.setCurrentChamp(h);
		task.getMap()[5][4] = new ChampionCell(h);
		((Wizard) task.getCurrentChamp()).setLocation(new Point(5, 4));

		task.moveForward();
		task.setCurrentChamp(h);

}
}
