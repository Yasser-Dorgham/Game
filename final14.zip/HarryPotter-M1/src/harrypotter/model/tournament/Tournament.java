package harrypotter.model.tournament;

import static org.junit.Assert.assertFalse;
import harrypotter.model.character.Champion;
import harrypotter.model.character.GryffindorWizard;
import harrypotter.model.character.HufflepuffWizard;
import harrypotter.model.character.RavenclawWizard;
import harrypotter.model.character.SlytherinWizard;
import harrypotter.model.character.Wizard;
import harrypotter.model.magic.DamagingSpell;
import harrypotter.model.magic.HealingSpell;
import harrypotter.model.magic.RelocatingSpell;
import harrypotter.model.magic.Spell;
import harrypotter.model.world.ChampionCell;
import harrypotter.model.world.EmptyCell;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Tournament implements TaskListener {

	private ArrayList<Champion> champions;
	private ArrayList<Spell> spells;
	private FirstTask firstTask;
	private SecondTask secondTask;
	private ThirdTask thirdTask;

	public Tournament() throws IOException {

		champions = new ArrayList<Champion>();
		spells = new ArrayList<Spell>();
		loadSpells("Spells.csv");
		beginTournament();
		
		

	}

	private void loadSpells(String filePath) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();

		while (line != null) {

			String[] content = line.split(",");

			int cost = Integer.parseInt(content[2]);
			int defaultCoolDown = Integer.parseInt(content[4]);
			int amount = Integer.parseInt(content[3]);

			switch (content[0]) {

			case "DMG":

				spells.add(new DamagingSpell(content[1], cost, defaultCoolDown,
						amount));
				break;

			case "HEL":

				spells.add(new HealingSpell(content[1], cost, defaultCoolDown,
						amount));
				break;

			case "REL":

				spells.add(new RelocatingSpell(content[1], cost,
						defaultCoolDown, amount));
				break;

			}

			line = br.readLine();

		}

		br.close();

	}

	public ArrayList<Champion> getChampions() {

		return champions;

	}

	public ArrayList<Spell> getSpells() {

		return spells;

	}

	public FirstTask getFirstTask() {

		return firstTask;

	}

	public SecondTask getSecondTask() {

		return secondTask;

	}

	public ThirdTask getThirdTask() {

		return thirdTask;

	}
	public void addChampion(Champion c)
	{
		champions.add(c);
	}
     
	public void beginTournament() throws IOException
	{
		
		
		this.firstTask  = new FirstTask(champions);
		firstTask.setListener(this);
		
	}
	public void onFinishingFirstTask(ArrayList<Champion> winners) throws IOException // yeb3at el winners le 2nd task yebda2 beehom//
	{
		//System.out.println("da5al el onfinishfirst1");
		//System.out.println(firstTask!= null);
		//System.out.println(firstTask.getWinners()!= null);
		//System.out.println(firstTask.getWinners().size() + "fe onfinish");
		if (winners.size()!=0)
		{

		//System.out.println("da5al el onfinishfirst");
		this.secondTask  = new SecondTask(winners);
		secondTask.setListener(this);
			}
		}
	
		
		// edany error fa zawedt el exception fo2 we bel taly zawedto felinterface we fe firstTask fe notify on finishing de 
	public void onFinishingSecondTask(ArrayList<Champion> winners) throws IOException
	{
		if (winners.size()!= 0)
		{
		this.thirdTask  = new ThirdTask(winners);
		thirdTask.setListener(this);
		}
		/*else
			beginTournament();*/
		

	}
	public void onFinishingThirdTask(Champion winner)
	{
		
	}
	public static void main(String[] args) throws IOException {
		
		ArrayList<Champion> e = new ArrayList<>();
		GryffindorWizard g = new GryffindorWizard("gryff");
		HufflepuffWizard h = new HufflepuffWizard("huff");
		RavenclawWizard r = new RavenclawWizard("raven");
		SlytherinWizard s = new SlytherinWizard("slyth");
		e.add(s);
		e.add(h);
		e.add(r);
		e.add(g);
		FirstTask task = new FirstTask(e);

		for (int i = 0; i < 10; i++)
			for (int j = 0; j < 10; j++)
				task.getMap()[i][j] = new EmptyCell();
		Tournament t = new Tournament() ;
		t.addChampion(s);
		t.addChampion(h);
		t.addChampion(r);
		t.addChampion(g);
			
			

		task.setListener(t);
		task.setCurrentChamp(s);
		task.getMap()[5][4] = new ChampionCell(s);

		((Wizard) task.getCurrentChamp()).setLocation(new Point(5, 4));

		task.getMap()[3][4] = new ChampionCell(h);
		h.setLocation(new Point(3, 4));

		task.getMap()[4][5] = new ChampionCell(r);
		r.setLocation(new Point(4, 5));

		task.getMap()[4][3] = new ChampionCell(g);
		g.setLocation(new Point(4, 3));
		//System.out.println(task.getWinners().size() + " fel main");

		task.setListener(t);

		task.moveForward();
	

		task.setCurrentChamp(h);
		task.moveBackward();
		

		task.setCurrentChamp(r);
		task.moveLeft();
		

		task.setCurrentChamp(g);
		task.moveRight();
		//System.out.println(task.getWinners().size() + " fel main");
	}
}
