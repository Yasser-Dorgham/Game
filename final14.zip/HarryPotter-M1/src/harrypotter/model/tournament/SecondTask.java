package harrypotter.model.tournament;

import static org.junit.Assert.assertEquals;
import harrypotter.model.character.Champion;
import harrypotter.model.character.GryffindorWizard;
import harrypotter.model.character.HufflepuffWizard;
import harrypotter.model.character.RavenclawWizard;
import harrypotter.model.character.SlytherinWizard;
import harrypotter.model.character.Wizard;
import harrypotter.model.magic.Potion;
import harrypotter.model.world.Cell;
import harrypotter.model.world.ChampionCell;
import harrypotter.model.world.CollectibleCell;
import harrypotter.model.world.CupCell;
import harrypotter.model.world.Direction;
import harrypotter.model.world.EmptyCell;
import harrypotter.model.world.Merperson;
import harrypotter.model.world.ObstacleCell;
import harrypotter.model.world.TreasureCell;

import java.awt.Point;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class SecondTask extends Task {
	private ArrayList<Champion> winners;
	public SecondTask(ArrayList<Champion> champions) throws IOException {

		super(champions);
		Collections.shuffle(champions);
		generateMap();
		winners = new ArrayList<Champion>();
		for (int i = 0; i<champions.size(); i++)
		{
			Wizard z = ((Wizard)champions.get(i));
			z.setListener(this);
		}
		if (getChampions().size()!=0)
			setCurrentChamp(champions.get(0));
		
		
		// fe7aga kona 3amlinha 3,alat fel constructer enena ben2ool el winners homa el champions fa me7tageen now ne3mel a new arraylist lel winners we ne add feh

	}

	public void generateMap() {

		Cell[][] map = getMap();

		initializeAllEmpty();

		allocateChampions();

		int count = 0;
		while (count < 40) {

			int randomX = (int) (Math.random() * 10);
			int randomY = (int) (Math.random() * 10);

			if (map[randomX][randomY] instanceof EmptyCell) {

				int hp = (int) ((Math.random() * 101) + 200);
				int dmg = (int) ((Math.random() * 201) + 100);
				map[randomX][randomY] = new ObstacleCell(new Merperson(hp, dmg));
				count++;

			}

		}

		count = 0;
		while (count < getChampions().size()) {

			int randomX = (int) (Math.random() * 10);
			int randomY = (int) (Math.random() * 10);
			if (map[randomX][randomY] instanceof EmptyCell) {

				map[randomX][randomY] = new TreasureCell(getChampions().get(
						count));
				count++;

			}

		}

		allocatePotions();

	}
	public ArrayList<Champion> getWinners() {
		return winners;
	}
	public void setWinners(ArrayList<Champion> winners) {
		this.winners = winners;
	}
	public void encounterMerPerson() throws IOException
	{
		System.out.println("da5al el encounter");
	Wizard z = (Wizard)getCurrentChamp();
	Point x = getTargetPoint(Direction.FORWARD);
	
	if(x.x<=9 && x.y<=9 && x.x>=0 && x.y>=0)
	{
		//System.out.println("da5al el encounter2");
	if (getMap()[x.x][x.y]instanceof ObstacleCell) 
	{
		
		int d= ((Merperson)((ObstacleCell)getMap()[x.x][x.y]).getObstacle()).getDamage();
		int h = z.getHp();
		z.setHp(h-d);		
	}
	}
	x= getTargetPoint(Direction.BACKWARD);
	if(x.x<=9 && x.y<=9 && x.x>=0 && x.y>=0)
	{
		//System.out.println("da5al el encounter3");
	if (getMap()[x.x][x.y]instanceof ObstacleCell) 
	{
		int d= ((Merperson)((ObstacleCell)getMap()[x.x][x.y]).getObstacle()).getDamage();
		int h = z.getHp();
		z.setHp(h-d);		
	}
	}
	 x = getTargetPoint(Direction.LEFT);
	 if(x.x<=9 && x.y<=9 && x.x>=0 && x.y>=0)
	 {
		// System.out.println("da5al el encounter4");
	 if (getMap()[x.x][x.y]instanceof ObstacleCell) 
		{
			int d= ((Merperson)((ObstacleCell)getMap()[x.x][x.y]).getObstacle()).getDamage();
			int h = z.getHp();
			z.setHp(h-d);		
		}
	 }
	 x = getTargetPoint(Direction.RIGHT);
	 if(x.x<=9 && x.y<=9 && x.x>=0 && x.y>=0)
	 {
		 //System.out.println("da5al el encounter5");
	 if (getMap()[x.x][x.y]instanceof ObstacleCell) 
		{
			int d= ((Merperson)((ObstacleCell)getMap()[x.x][x.y]).getObstacle()).getDamage();
			int h = z.getHp();			
			z.setHp(h-d);		
		}
	 }
	int f = z.getHp();
	if (f<=0)
	{
		z.setHp(0);
		getChampions().remove(z);
		//setCurrentChamp(null);
		getMap()[z.getLocation().x][z.getLocation().y]= new EmptyCell();
		
	
	}
	else
		{
			z.setHp(f);
		}
	}
	
	
	
/*public void finalizeAction() throws IOException
{
	
	
	if (!(getCurrentChamp() instanceof HufflepuffWizard))
	{
		encounterMerPerson();
	}
	super.finalizeAction();
}*/
	

	
	public void endTurn() throws IOException
	{
		System.out.println("da5al el end elle fel second");
		if (getCurrentChamp() instanceof HufflepuffWizard && isTraitActivated())
		{
		}
		else
		{
			encounterMerPerson();
		}
		super.endTurn();
	}
public void onSlytherinTrait(Direction d) throws IOException
{
	((SlytherinWizard)getCurrentChamp()).setTraitCooldown(4);
	super.onSlytherinTrait(d);
	
	
	
}
public void onHufflepuffTrait()
{
	((HufflepuffWizard)getCurrentChamp()).setTraitCooldown(6);
	super.onHufflepuffTrait();
	
}
public Object onRavenclawTrait()
{
	int x = 10;
	int y = 10;
	for (int i = 0; i<10 ; i++)
	{
		for (int j=0; j<10; j++)
		{
			Cell c =  getMap()[i][j];
			if (c instanceof TreasureCell)
				if (((TreasureCell) c).getOwner() instanceof RavenclawWizard)
				{
					x=i;
					y=j;
				}
		}
	}
	int l = (((Wizard)getCurrentChamp()).getLocation()).x;
	int m = (((Wizard)getCurrentChamp()).getLocation()).y;
	ArrayList<Direction> r = new ArrayList<Direction>(); ;

	if(x!= 10 && y!=10)
		{
		
			
			if (l<x) //kona metla3'bateen fe dol
				r.add(Direction.BACKWARD);
			if (l>x)
				r.add(Direction.FORWARD);
			if(y<m)
				r.add(Direction.LEFT);
			if(y>m)
				r.add(Direction.RIGHT);
			}
		
		
		
	setTraitActivated(true);
	((RavenclawWizard)getCurrentChamp()).setTraitCooldown(7);
	return r;
}

 public void notifyOnFinishingSecondTask() throws IOException
 {
	 if (getListener() != null)
	 getListener().onFinishingSecondTask(winners); // badal ma kona 3amlin Tournament.onFinishing.... han-invoke el method 3ala el listener which is of type tournament bardo . bas e7na malnasg access 3ala tournament ela men 5elal el listener
 }
 public static void main(String[] args) throws IOException {
	 ArrayList<Champion> e = new ArrayList<>();
		SlytherinWizard r = new SlytherinWizard("raven");
		SlytherinWizard s = new SlytherinWizard("slyth");
		e.add(r);
		e.add(s);
		SecondTask task = null;
		int x, y;
		Point location = null;

		do {
			task = new SecondTask(e);

			for (int i = 0; i < 10; i++) {
				for (int j = 0; j < 10; j++) {
					if (task.getMap()[i][j] instanceof TreasureCell) {
						if (((TreasureCell) task.getMap()[i][j]).getOwner() == s) {
							location = new Point(i, j);
						}
					}

				}
			}

			x = location.x;
			y = location.y;

			if (x > 1 && x < 8 && y < 7 && y > 2)
				break;
		} while (true);

		task.getMap()[x][y - 1] = new EmptyCell();

		task.getMap()[x - 1][y] = new ObstacleCell(new Merperson(100, 100));
		task.getMap()[x - 1][y - 1] = new ObstacleCell(new Merperson(100, 100));
		task.getMap()[x + 1][y - 1] = new ObstacleCell(new Merperson(100, 100));
		task.getMap()[x][y - 2] = new ChampionCell(s);
		task.setCurrentChamp(s);
		Wizard currentChamp = ((Wizard) task.getCurrentChamp());
		currentChamp.setLocation(new Point(x, y - 2));

		int hpOld = currentChamp.getHp();
		task.moveRight();

		task.setCurrentChamp(s);
		hpOld = currentChamp.getHp();
		task.moveRight();
		
}

}